package com.example.Team_10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Team10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
